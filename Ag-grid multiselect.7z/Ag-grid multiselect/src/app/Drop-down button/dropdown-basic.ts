
import {Component} from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular/main";
import { IMultiSelectOption,IMultiSelectTexts ,IMultiSelectSettings  } from 'angular-2-dropdown-multiselect';
import{appDataService}from '../appdata.service'
@Component({
    selector: 'ngbd-dropdown-basic',
    template: '<ss-multiselect-dropdown [options]="myOptions" [texts]="myTexts" [settings]="mySettings" [(ngModel)]="optionsModel"></ss-multiselect-dropdown>'
})
export class NgbdDropdownBasic  implements ICellRendererAngularComp {
    // Default selection
optionsModel: number[] = [1, 2];
public params: any;

    agInit(params: any): void {
        debugger;
        this.params = params;
    }
// Settings configuration
mySettings: IMultiSelectSettings;
// Text configuration
myTexts: IMultiSelectTexts;
// Labels / Parents
myOptions: IMultiSelectOption[];
constructor(dataService:appDataService){
    this.myOptions=dataService.ddOptions;
    this.mySettings=dataService.ddSettings;
    this.myTexts=dataService.ddSettings;
}
}
