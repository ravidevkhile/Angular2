import {Component, ViewContainerRef, ViewChild, AfterViewInit} from '@angular/core';
import { IMultiSelectOption,IMultiSelectTexts ,IMultiSelectSettings  } from 'angular-2-dropdown-multiselect';
import {ICellEditorAngularComp} from 'ag-grid-angular/main';
import{appDataService}from '../appdata.service'
@Component({
    selector: 'editor-cell',
    template: `
        <div #container class="mood" tabindex="0" (keydown)="onKeyDown($event)">            
            <ss-multiselect-dropdown [options]="myOptions" [texts]="myTexts" [settings]="mySettings" [(ngModel)]="optionsModel"></ss-multiselect-dropdown>
        </div>
    `,
    styles: [``]
})
export class MoodEditorComponent implements ICellEditorAngularComp, AfterViewInit {
    private params: any;

    @ViewChild('container', {read: ViewContainerRef}) public container;
    public happy: boolean = false;
    // Settings configuration
mySettings: IMultiSelectSettings;
// Text configuration
myTexts: IMultiSelectTexts;
// Labels / Parents
myOptions: IMultiSelectOption[];
constructor(dataService:appDataService){
    this.myOptions=dataService.ddOptions;
    this.mySettings=dataService.ddSettings;
    this.myTexts=dataService.ddSettings;
}
    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {
        this.container.element.nativeElement.focus();
    }

    agInit(params: any): void {
        debugger;
        this.params = params;
        this.setHappy(params.value === "Happy");
    }

    getValue(): any {
        debugger;
        return this.happy ? "Happy" : "Sad";
    }

    isPopup(): boolean {
        return true;
    }

    setHappy(happy: boolean): void {
        this.happy = happy;
    }

    toggleMood(): void {
        this.setHappy(!this.happy);
    }

    onClick(happy:boolean) {
        this.setHappy(happy);
        this.params.api.stopEditing();
    }

    onKeyDown(event): void {
        let key = event.which || event.keyCode;
        if (key == 37 ||  // left
            key == 39) {  // right
            this.toggleMood();
            event.stopPropagation();
        }
    }
}