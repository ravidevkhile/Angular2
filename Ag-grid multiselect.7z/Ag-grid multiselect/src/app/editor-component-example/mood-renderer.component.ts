import {Component} from '@angular/core';

import {ICellRendererAngularComp} from 'ag-grid-angular/main';
import { IMultiSelectOption,IMultiSelectTexts ,IMultiSelectSettings  } from 'angular-2-dropdown-multiselect';
import{appDataService}from '../appdata.service'
@Component({
    selector: 'mood-cell',
    template: `<div *ngIf='params.cellStartedEdit'><ss-multiselect-dropdown [options]="myOptions" [texts]="myTexts" [settings]="mySettings" [(ngModel)]="optionsModel"></ss-multiselect-dropdown>
    </div>`
})
export class MoodRendererComponent implements ICellRendererAngularComp {
    private params: any;
    private mood: string;
    public imgForMood: string;
mySettings: IMultiSelectSettings;
// Text configuration
myTexts: IMultiSelectTexts;
// Labels / Parents
myOptions: IMultiSelectOption[];
constructor(dataService:appDataService){
    this.myOptions=dataService.ddOptions;
    this.mySettings=dataService.ddSettings;
    this.myTexts=dataService.ddSettings;
}

    agInit(params: any): void {
        this.params = params;
        this.setMood(params);
    }

    refresh(params: any): void {
        this.params = params;
        this.setMood(params);
    }

    private setMood(params) {
        this.mood = params.value;
        this.imgForMood = this.mood === 'Happy' ? 'https://www.ag-grid.com/images/smiley.png' : 'https://www.ag-grid.com/images/smiley-sad.png';
    };
}

