import {Component} from "@angular/core";
import {LicenseManager} from "ag-grid-enterprise/main";
import { NgbdDropdownBasic} from './Drop-down button/dropdown-basic'
// import { NgbModule } from '/node_modules/bootstrap/ng-bootstrap';

// http://plnkr.co/edit/?p=preview/
@Component({
    selector: 'my-app',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    
}