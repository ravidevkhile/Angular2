import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {FormsModule} from "@angular/forms";
// ag-grid
import {AgGridModule} from "ag-grid-angular/main";
// application
import {AppComponent} from "./app.component";
import {SquareComponent} from "./dynamic-component-example/square.component";
import {ParamsComponent} from "./dynamic-component-example/params.component";
import {CubeComponent} from "./dynamic-component-example/cube.component";
import {CurrencyComponent} from "./dynamic-component-example/currency.component";
import {ChildMessageComponent} from "./dynamic-component-example/child-message.component";
// rich grid
import {RichGridComponent} from "./rich-grid-example/rich-grid.component";
import {DateComponent} from "./date-component/date.component";
import {HeaderComponent} from "./header-component/header.component";
import {HeaderGroupComponent} from "./header-group-component/header-group.component";
import {GroupRowComponent} from "./grouped-row-example/group-row-renderer.component";
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import{NgbdDropdownBasic} from './Drop-down button/dropdown-basic'
import {EditorComponent} from "./editor-component-example/editor.component";
import {NumericEditorComponent} from "./editor-component-example/numeric-editor.component";
import {MoodEditorComponent} from "./editor-component-example/mood-editor.component";
import {MoodRendererComponent} from "./editor-component-example/mood-renderer.component";
import{appDataService}from './appdata.service'
@NgModule({
    imports: [
        BrowserModule,
        FormsModule,MultiselectDropdownModule,
        AgGridModule.withComponents(
            [
                DateComponent,
                HeaderComponent,
                HeaderGroupComponent,SquareComponent,
                CubeComponent,
                ParamsComponent,
                CurrencyComponent,
                ChildMessageComponent,NumericEditorComponent,
                MoodEditorComponent,
                MoodRendererComponent
            ]
        )
    ],providers: [appDataService],
    declarations: [
        AppComponent,
        RichGridComponent,
        DateComponent,
        HeaderComponent,
        HeaderGroupComponent,GroupRowComponent,NgbdDropdownBasic,
        SquareComponent,
        CubeComponent,
        ParamsComponent,
        CurrencyComponent,NumericEditorComponent,
                MoodEditorComponent,
EditorComponent,        ChildMessageComponent,MoodRendererComponent
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}
