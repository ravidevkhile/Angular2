import {Component} from "@angular/core";
import {ICellRendererAngularComp,ICellEditorAngularComp} from "ag-grid-angular/main";
import { IMultiSelectOption,IMultiSelectTexts ,IMultiSelectSettings  } from 'angular-2-dropdown-multiselect';
@Component({
    selector: 'child-cell',
    template: `
            <div #container tabindex="0" (keydown)="onKeyDown($event)">
    <ss-multiselect-dropdown [options]="myOptions" [texts]="myTexts" [settings]="mySettings" [(ngModel)]="optionsModel"></ss-multiselect-dropdown>
        </div>`


})
export class ChildMessageComponent implements ICellRendererAngularComp {
    // Default selection
optionsModel: number[] = [1, 2];
public params: any;
ngAfterViewInit() {
       
    }
    agInit(params: any): void { 
        debugger;      
        this.params = params;
    }
// Settings configuration
mySettings: IMultiSelectSettings = {
    enableSearch: true,
    checkedStyle: 'checkboxes',
    buttonClasses: 'btn btn-default btn-block',
    dynamicTitleMaxItems: 3,
    displayAllSelectedText: true
};

// Text configuration
myTexts: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find',
    defaultTitle: 'Select',
    allSelected: 'All selected',
};

// Labels / Parents
myOptions: IMultiSelectOption[] = [
    { id: 1, name: 'Car brands', isLabel: true },
    { id: 2, name: 'Volvo', parentId: 1 },
    { id: 3, name: 'Honda', parentId: 1 },
    { id: 4, name: 'BMW', parentId: 1 },
    { id: 5, name: 'Colors', isLabel: true },
    { id: 6, name: 'Blue', parentId: 5 },
    { id: 7, name: 'Red', parentId: 5 },
    { id: 8, name: 'White', parentId: 5 }
];
}
