
import {Component} from '@angular/core';

@Component({
    selector: 'ngbd-dropdown-basic',
    templateUrl: 'src/dropdown-basic.html'
})
export class NgbdDropdownBasic {
}
